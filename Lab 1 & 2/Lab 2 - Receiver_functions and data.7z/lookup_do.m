function [d1] = lookup_do(i1, table);

d1 = table(i1+1);
